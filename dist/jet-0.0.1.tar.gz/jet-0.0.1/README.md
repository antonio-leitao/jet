### Todo
-> Add footer (takes keys and displays them into columns)
-> Super 

The package requires gum to run!